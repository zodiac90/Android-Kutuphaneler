package com.melnykov.fab;

public interface ScrollDirectionListener {
    void onScrollDown();

    void onScrollUp();
}