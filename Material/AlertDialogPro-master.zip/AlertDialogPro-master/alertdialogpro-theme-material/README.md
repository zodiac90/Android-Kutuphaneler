alertdialogpro-theme-material
=============================

This is **Material** theme resource of **AlertDialogPro**. Add this project as an addition of **[alertdialogpro-core](https://github.com/fengdai/AlertDialogPro/tree/master/alertdialogpro-core)** can get a **Material** theme.

![alt](https://github.com/fengdai/AlertDialogPro/blob/master/image/material_dark.png)
![alt](https://github.com/fengdai/AlertDialogPro/blob/master/image/material_light.png)
