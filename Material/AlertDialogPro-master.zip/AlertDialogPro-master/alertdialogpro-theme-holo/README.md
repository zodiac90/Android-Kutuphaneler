alertdialogpro-theme-holo
=========================

This is **Holo** theme resource of **AlertDialogPro**. Add this project as an addition of **[alertdialogpro](https://github.com/fengdai/AlertDialogPro/tree/master/alertdialogpro)** can get a **Holo** theme.

![alt](https://github.com/fengdai/AlertDialogPro/blob/master/image/holo_dark.png)
![alt](https://github.com/fengdai/AlertDialogPro/blob/master/image/holo_light.png)
