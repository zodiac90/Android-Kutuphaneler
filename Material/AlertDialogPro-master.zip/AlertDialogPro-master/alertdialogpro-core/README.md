alertdialogpro
==============

This is the core project of **AlertDialogPro**.