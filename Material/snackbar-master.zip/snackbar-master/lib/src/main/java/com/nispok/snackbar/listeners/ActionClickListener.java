package com.nispok.snackbar.listeners;

import com.nispok.snackbar.Snackbar;

public interface ActionClickListener {
    void onActionClicked(Snackbar snackbar);
}
