AndroidMaterialDesignToolbar
============================
[![Android Arsenal](https://img.shields.io/badge/Android%20Arsenal-AndroidMaterialDesignToolbar-brightgreen.svg?style=flat)](https://android-arsenal.com/details/3/1125)

Android Sample Project with Material Design and Toolbar.
Project use Appcompat library for material design.

Project Contain
============================
*Material Design Theme

*Toolbar

*NavigationDrawer

*new SlidingTabLayout

*ViewPager

*Material FloatingActionButton

*Material CircularProgressBar

*SwitchCompat from Appcompat

*EditText from Appcompat

*Checkbox from Appcompat


![alt tag](http://www.stdroid.com/img/output_5UTjCv.gif)
