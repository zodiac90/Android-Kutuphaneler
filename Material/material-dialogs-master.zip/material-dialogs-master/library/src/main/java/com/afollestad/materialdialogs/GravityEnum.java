package com.afollestad.materialdialogs;

public enum GravityEnum {
    START, CENTER, END
}