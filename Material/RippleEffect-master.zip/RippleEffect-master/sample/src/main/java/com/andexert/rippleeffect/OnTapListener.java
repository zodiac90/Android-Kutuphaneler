package com.andexert.rippleeffect;

/**
 * Created by TraeX on 24/10/14.
 */
public interface OnTapListener
{
    public void onTapView(int position);
}
